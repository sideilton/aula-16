# 16-Metodologia_Box-Jenkings
Metodo BJ
